package test;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ BotonMinaTest.class, MatrizBotonesTest.class })
public class AllTests {

}
