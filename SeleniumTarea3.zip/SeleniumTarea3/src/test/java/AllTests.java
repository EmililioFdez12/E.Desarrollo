import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

@Suite
@SelectClasses({ SeleniumTarea3.class, SeleniumTarea3P_Calculadora.class })
public class AllTests {

}
